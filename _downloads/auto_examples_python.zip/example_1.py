"""
=======
Example
=======


Here is an example "example" script (so meta!). You'd create examples like this
and the documentation Makefile will run them during the doc build.

.. raw:: html

   <br/>
"""
print(__doc__)

# Author: Taylor Smith <taylor.smith@alkaline-ml.com>

print("Here's an example!")
